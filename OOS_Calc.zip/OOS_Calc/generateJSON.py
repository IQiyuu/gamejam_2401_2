import gspread
from google.oauth2.service_account import Credentials
import json
import os

# Fonction pour collecter les données et les formater
def collect_data(char):
    # Crée une instance de gspread pour accéder aux données
    scopes = ["https://www.googleapis.com/auth/spreadsheets"]
    creds = Credentials.from_service_account_file("key.json", scopes=scopes)
    client = gspread.authorize(creds)
    sheet_id = "11c5gJ0jQ9Axoqqm_7Nx4Zv-pOIH_rMTVDLsWKX8yfM8"
    sheet = client.open_by_key(sheet_id)

    def keep(lst, smallest=True):
        n_lst = list()
        for value in lst:
            try:
                val = value[0].split("/")
            except:
                val = "999"
            if (len(value) > 1):
                if (smallest):
                    s = 999
                    for v in val:
                        if int(v) < s:
                            s = int(v)
                    val = s
                else:
                    s = -999
                    for v in val:
                        if int(v) > s:
                            s = int(v)
                    val = s
            else:
                val = int(val[0])
            n_lst.append(val)
        return n_lst

    def rearange(dic):
        n_dic = dict()
        for name, value in dic.items():
            if " Grab" in name or "Grab " in name or ("Jab" in name and "1" not in name) or name == "Rapid jab" or name == "Rapid Jab" or name == "rapid jab" or name == "rapid Jab":
                continue
            elif "Air" in name or "gun" in name or "Gun" in name:
                n_dic[name] = value + 3
            elif name == "U-Smash":
                 n_dic[name] = value
            elif name == "Grab":
                 n_dic[name] = value + 4
            else:
                n_dic[name] = value + 11
        return n_dic
    

    def rearange2(dic):
        n_dic = dict()
        for name, value in dic.items():
            if name == "Rapid jab" or name == "Rapid Jab" or name == "rapid jab" or name == "rapid Jab" or name == "Pummel":
                continue
            else:
                n_dic[name] = value
        return n_dic
    
    def rearange3(dic):
        n_dic = dict()
        for name, value in dic.items():
            if " Grab" in name or "Grab " in name or ("Jab" in name and "1" not in name) or name == "Rapid jab" or name == "Rapid Jab" or name == "rapid jab" or name == "rapid Jab":
                continue
            elif "Air" in name:
                n_dic[name] = value + 3
            else:
                n_dic[name] = value
        return n_dic

    def createDict(wsheet):
        names = wsheet.get("A2:A")
        oos =  wsheet.get("B2:B")
        os = wsheet.get("C2:C")
        value_oos = dict()
        value_os = dict()
        value_su = dict()
        oos = keep(oos, True)
        os = keep(os, False)
        for i in range(0, len(names)):
            try:
                value_oos[names[i][0]] = oos[i]
            except:
                break
        for i in range(0, len(names)):
            try:
                value_os[names[i][0]] = os[i]
            except:
                break
        for i in range(0, len(names)):
            try:
                value_su[names[i][0]] = oos[i]
            except:
                break
        
        value_oos = rearange(value_oos)
        value_os = rearange2(value_os)
        value_su = rearange3(value_su)
        value_oos = dict(sorted(value_oos.items(), key=lambda item: item[1]))
        value_os = dict(sorted(value_os.items(), key=lambda item: item[1], reverse=True))
        value_su = dict(sorted(value_su.items(), key=lambda item: item[1]))
        return value_oos, value_os, value_su


    try:
        Sheet = sheet.worksheet(char)
    except:
        print ("Error: "+char)
        return None
    dictOOS,dictOS,dictSU = createDict(Sheet)
    data = {
        char: [{
            "OOS": dictOOS,
            "SU": dictSU,
            "OS": dictOS
        }]
    }
    

    return data



# if __name__ == "__main__":
#     pChar = "Mario"
#     eChar = "Link"

#     if not os.path.exists(f"./datas/{pChar}.json"):
#         pCharData = collect_data(pChar)
#         data = json.dumps(pCharData)
#         with open(f"./datas/{pChar}.json", 'w') as f:
#             json.dump(data, f)

#     if not os.path.exists(f"./datas/{eChar}.json"):
#         eCharData = collect_data(eChar)
#         data = json.dumps(eCharData)
#         with open(f"./datas/{eChar}.json", 'w') as f:
#             json.dump(data, f)
# \"F-Air Landing\": 17,

personnages_smash = [
    "Banjo & Kazooie", "Bayonetta", "Bowser", "Bowser Jr", "Byleth", "Captain Falcon", 
    "Charizard", "Chrom", "Cloud", "Corrin", "Daisy", "Diddy Kong", "Donkey Kong", "Dr. Mario",
    "Duck Hunt", "Falco", "Fox", "Ganondorf", "Greninja", "Hero", "Ice Climbers", "Inkling", 
    "Incineroar", "Isabelle", "Ivysaur", "Jigglypuff", "Joker", "Ken", "King Dedede", "King K Rool", "Kirby",
    "Kazuya", "Link", "Little Mac", "Lucario", "Lucas", "Lucina", "Luigi", "Mario", "Marth", 
    "Mega Man", "Meta Knight", "Min Min", "Mewtwo", "Mr. Game & Watch", "Mythra", "Ness", "Olimar", "Palutena", 
    "Peach", "Pichu", "Pikachu", "Pit", "Piranha Plant", "Pyra", "Richter", "Ridley", "Robin", "R.O.B.", 
    "Roy", "Ryu", "Sephiroth", "Sheik", "Shulk", "Snake", "Sonic", "Steve", "Terry", "Toon Link", 
    "Villager", "Wario", "Wolf", "Wii Fit Trainer", "Yoshi", "Young Link", "Zelda", "Zero Suit Samus"
]

for perso in personnages_smash:
    end = False
    while not end:
        try:
            print (perso)
            char = collect_data(perso)
            if (char == None):
                continue
            data = json.dumps(char)
            with open(f"./datas/{perso}.json", 'w') as f:
                json.dump(data, f)
            end = True
        except:
            end = False