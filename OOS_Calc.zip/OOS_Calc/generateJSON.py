import gspread
from google.oauth2.service_account import Credentials
import json
import os

# Fonction pour collecter les données et les formater
def collect_data(char):
    # Crée une instance de gspread pour accéder aux données
    scopes = ["https://www.googleapis.com/auth/spreadsheets"]
    creds = Credentials.from_service_account_file("key.json", scopes=scopes)
    client = gspread.authorize(creds)
    sheet_id = "11c5gJ0jQ9Axoqqm_7Nx4Zv-pOIH_rMTVDLsWKX8yfM8"
    sheet = client.open_by_key(sheet_id)

    def keep(lst, smallest=True):
        n_lst = list()
        for value in lst:
            try:
                val = value[0].split("/")
            except:
                val = "999"
            if (len(value) > 1):
                if (smallest):
                    s = 999
                    for v in val:
                        if int(v) < s:
                            s = int(v)
                    val = s
                else:
                    s = -999
                    for v in val:
                        if int(v) > s:
                            s = int(v)
                    val = s
            else:
                val = int(val[0])
            n_lst.append(val)
        return n_lst

    def rearange(dic):
        n_dic = dict()
        for name, value in dic.items():
            if " Grab" in name or ("Jab" in name and "1" not in name):
                continue
            if "Air" in name:
                n_dic[name] = value + 3
            else:
                n_dic[name] = value + 11
        return n_dic

    def createDict(wsheet):
        names = wsheet.get("A2:A")
        oos =  wsheet.get("B2:B")
        os = wsheet.get("C2:C")
        value_oos = dict()
        value_os = dict()
        oos = keep(oos, True)
        os = keep(os, False)
        for i in range(0, len(names)):
            try:
                value_oos[names[i][0]] = oos[i]
            except:
                break
        for i in range(0, len(names)):
            try:
                value_os[names[i][0]] = os[i]
            except:
                break
        value_oos = rearange(value_oos)
        value_oos = dict(sorted(value_oos.items(), key=lambda item: item[1]))
        value_os = dict(sorted(value_os.items(), key=lambda item: item[1], reverse=True))
        return value_oos, value_os


    try:
        Sheet = sheet.worksheet(char)
    except:
        print ("Error: "+char)
        return None
    dictOOS,dictOS = createDict(Sheet)
    data = {
        char: [{
            "OOS": dictOOS,
            "OS": dictOS
        }]
    }
    

    return data



# if __name__ == "__main__":
#     pChar = "Mario"
#     eChar = "Link"

#     if not os.path.exists(f"./datas/{pChar}.json"):
#         pCharData = collect_data(pChar)
#         data = json.dumps(pCharData)
#         with open(f"./datas/{pChar}.json", 'w') as f:
#             json.dump(data, f)

#     if not os.path.exists(f"./datas/{eChar}.json"):
#         eCharData = collect_data(eChar)
#         data = json.dumps(eCharData)
#         with open(f"./datas/{eChar}.json", 'w') as f:
#             json.dump(data, f)

personnages_smash = [
    "Mario", "Donkey Kong", "Link", "Samus", "Yoshi", "Kirby", "Fox", "Pikachu", "Luigi", 
    "Ness", "Captain Falcon", "Jigglypuff", "Peach", "Bowser", "Ice Climbers", "Sheik", 
    "Zelda", "Dr. Mario", "Pichu", "Falco", "Marth", "Lucina", "Roy", "Chrom", "Robin", "Villager", 
    "Mega Man", "Wario", "Palutena", "Duck Hunt", "R.O.B.", "Toon Link", "Mega Man", "Little Mac", 
    "Greninja", "Cloud", "Bayonetta", "Inkling", 
    "Ridley", "Simon", "Richter", "King K Rool", "Isabelle", "Incineroar", "Piranha Plant", 
    "Joker", "Hero", "Banjo & Kazooie", "Terry", "Byleth", "Min Min", "Steve", "Sephiroth", 
    "Pyra", "Mythra", "Kazuya", "Sora", "Charizard", "Squirtle", "Ivysaur", "Mr. Game & Watch", "Young Link", "Ganondorf", "Mewtwo", "Meta Knight", "Pit", "Zero Suit Samus", "Snake", "Diddy Kong", "Sonic", "Lucario", "King Dedede", "Lucas", "Wolf", "Wii Fit Trainer", "Rosalina & Luma", "PAC-MAN", "Shulk", "Bowser Jr", "Corrin", "Ryu"
]

for perso in personnages_smash:
    if not os.path.exists(f"./datas/{perso}.json"):
        print (perso)
        char = collect_data(perso)
        if (char == None):
            continue
        data = json.dumps(char)
        with open(f"./datas/{perso}.json", 'w') as f:
            json.dump(data, f)